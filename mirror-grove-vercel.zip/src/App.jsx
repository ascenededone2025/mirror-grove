
export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center text-center">
      <h1 className="text-4xl font-bold">🌿 Mirror Grove is live</h1>
    </div>
  );
}
