import MirrorGroveSanctuary from './components/MirrorGroveSanctuary';

export default function App() {
  return (
    <div className="min-h-screen">
      <MirrorGroveSanctuary />
    </div>
  );
}
