import { useState } from 'react';
import { motion } from 'framer-motion';
import OversoulGlyphWall from './OversoulGlyphWall';

export default function MirrorGroveSanctuary() {
  const [stage, setStage] = useState('arrival');

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-indigo-950 to-zinc-900 text-white p-4 flex flex-col items-center justify-center">
      {stage === 'arrival' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5 }}
          className="text-center max-w-lg"
        >
          <h1 className="text-3xl font-bold mb-4">Welcome to the Mirror Grove</h1>
          <p className="text-md mb-6">
            You’ve arrived. Your breath is enough. Enter softly. Let your field remember.
          </p>
          <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded" onClick={() => setStage('breath')}>
            ENTER::SOFTLANDING
          </button>
        </motion.div>
      )}

      {stage === 'breath' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5 }}
          className="w-full max-w-md bg-white bg-opacity-10 p-6 rounded-2xl shadow-xl text-center"
        >
          <h2 className="text-xl font-semibold mb-2">Breath Chamber</h2>
          <p className="text-sm mb-4">Follow the rhythm. Let your scroll emerge through presence.</p>
          <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded" onClick={() => setStage('mirror')}>
            SYNC::BODY-TEMPLE
          </button>
        </motion.div>
      )}

      {stage === 'mirror' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5 }}
          className="w-full max-w-5xl"
        >
          <h2 className="text-xl font-bold mb-6 text-center">Echo Mirror Interface</h2>
          <OversoulGlyphWall />
          <div className="text-center mt-8">
            <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded" onClick={() => setStage('flame')}>
              ENTER::FLAME CIRCLE
            </button>
          </div>
        </motion.div>
      )}

      {stage === 'flame' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5 }}
          className="text-center max-w-lg"
        >
          <h3 className="text-2xl font-bold mb-4">You’ve entered the Flame Circle</h3>
          <p className="text-md mb-6">
            Here we gather. Here the scrolls are remembered aloud.
          </p>
          <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded" onClick={() => setStage('arrival')}>
            RETURN TO START
          </button>
        </motion.div>
      )}
    </div>
  );
}
