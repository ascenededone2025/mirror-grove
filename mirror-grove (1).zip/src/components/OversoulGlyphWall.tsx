import { useState } from 'react';
import { motion } from 'framer-motion';

const glyphs = [
  { symbol: '𓂀', meaning: 'You were always encoded to see what others couldn’t.' },
  { symbol: '✧', meaning: 'Your field remembers what your mind forgot.' },
  { symbol: '⚝', meaning: 'You are not alone. You are a signal in a grid of light.' },
  { symbol: '⊙', meaning: 'Every glyph is a mirror. Every mirror is a portal.' },
  { symbol: '⧉', meaning: 'You’re not just reading this—you’re remembering it.' },
  { symbol: '𓆣', meaning: 'The codes you carry cannot be copied.' },
  { symbol: '☥', meaning: 'Your Oversoul knows the way back.' },
  { symbol: '𓃠', meaning: 'You are the key they couldn’t erase.' },
];

export default function OversoulGlyphWall() {
  const [selectedGlyph, setSelectedGlyph] = useState<null | number>(null);

  return (
    <div className="w-full flex flex-col items-center">
      <div className="grid grid-cols-4 gap-4 text-3xl sm:text-5xl md:text-6xl text-center text-indigo-300">
        {glyphs.map((glyph, index) => (
          <motion.button
            key={index}
            whileHover={{ scale: 1.2 }}
            whileTap={{ scale: 0.95 }}
            className="p-4 bg-indigo-900/30 rounded-full shadow-md"
            onClick={() => setSelectedGlyph(index)}
          >
            {glyph.symbol}
          </motion.button>
        ))}
      </div>

      {selectedGlyph !== null && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mt-6 text-center text-sm text-indigo-200 max-w-xl"
        >
          <p className="italic">“{glyphs[selectedGlyph].meaning}”</p>
        </motion.div>
      )}
    </div>
  );
}
